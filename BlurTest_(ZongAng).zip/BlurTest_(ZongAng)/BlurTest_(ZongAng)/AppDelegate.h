//
//  AppDelegate.h
//  BlurTest_(ZongAng)
//
//  Created by mac on 16/7/30.
//  Copyright © 2016年 纵昂. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

